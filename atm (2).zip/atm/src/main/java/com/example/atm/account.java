package com.example.atm;
import java.util.*;
public class account {
	public long account_no;
	public double balance;
	public account(long account_no, double balance) {
		super();
		this.account_no = account_no;
		this.balance = balance;
	}
	public boolean withdraw(double amount) {
		if(amount>0 && amount<=balance)
		{
			balance-=amount;
			return true;
		}
		return false;
	}
	
	public void deposit(double amount) {
		if(amount>0) {
			balance+=amount;
		}
	}
	 public long getAccountNumber() {
	        return account_no;
	    }

}
