package com.example.atm;
import java.util.*;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/atm")
public class atmController {
	public account acc=new account(98586545,25000.0);
	
	@GetMapping
	public String showAtm(Model model)
	{
		model.addAttribute("account", acc);
		return "atm";
	}
	
	@PostMapping("/deposit")
	public String deposit(@RequestParam double amount)
	{
		acc.deposit(amount);
		return "redirect:/atm";
	}
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam double amount,Model model)
	{
		boolean suc=acc.withdraw(amount);
		
		  model.addAttribute("withdrawSuccess", suc);
	        model.addAttribute("account", acc);
	        return "atm";
	}
}
